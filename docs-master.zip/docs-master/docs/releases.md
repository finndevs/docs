# Release Notes

<!--
https://github.com/flarum/docs/issues/22
https://laravel.com/docs/5.7/releases

## Versioning Scheme

## Support Policy

## Release Notes
-->

Release notes can be found in the [Flarum Community](https://discuss.flarum.org/t/blog?sort=newest).
